 import java.util.Scanner;
 public class Question_03
 {
	public static void main (String args[])
	{
		int option;
		
		Scanner input=new Scanner(System.in);
		
		
		System.out.println("Enter the number");
		option=input.nextInt();

		
		
		if(option==1)
		{
			System.out.println("One for Sorrow");
		}
		else if(option==2)
		{
			System.out.println("Two for joy");
		}
		else if(option==3)
		{
			System.out.println("Three for a girl");
		}
		else if(option==4)
		{
			System.out.println("Four for boy");
		}
		else if(option==5)
		{
			System.out.println("Five for silver");
		}
		else if(option==6)
		{
			System.out.println("Six for gold");
		}
		else if(option==7)
		{
			System.out.println("Seven for a secret never to be told");
		}
		else
		{
			System.out.println("Not a permitted number");
		}

	}
}
