 import java.util.Scanner;
 public class Question_02
 {
	public static void main (String args[])
	{
		String pwd="Rocket";
		
		Scanner input=new Scanner(System.in);
		
		System.out.println("Enter the password");
		
		String pwd1 =input.nextLine();
		
		if(pwd == pwd1)
		{
			System.out.println("Welcome");
		}
		else
		{
			System.out.println("Incorrect Password");
		}

	}
}
